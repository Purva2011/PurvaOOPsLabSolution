package com.greatlearning.service;
import java.util.Random;

public class Credential {

	public String generateEmailAddress(String firstName, String lastName, String Department) {
		String emailAddress = firstName+lastName+"@"+Department+"company.com";
		return emailAddress;
	}
	public String Password() {
		//String Pass;
		String number = "1234567890";
		String Capital ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String Small = "abcdefghijklmnopqrstuvwxyz";
		String Special = "!@#$%^&*";
		Random R = new Random();
		String Values = number+Capital+Small+Special;
		char[] pass = new char[8];
		for (int i=0; i<8; i++) {
			pass[i] = Values.charAt(R.nextInt(Values.length()));
		}
		return pass.toString();
	}
}

