package com.greatlearning.main;

import java.util.Scanner;

import com.greatlearning.model.Employee;
import com.greatlearning.service.Credential;

	public class DriverClass {
	public static Employee employee = new Employee("Purva","Tendulkar");
	public static Credential Credential = new Credential();
	public static Scanner scanner = new Scanner (System.in);
	public static String Dept = "";
	public static String test = "";
	
		public static void main (String[] args) {
				displayMenu();
				int Choice = scanner.nextInt();
				switch(Choice) {
					case 1: //System.out.println("Technical Option is selected");
					Dept = "Tech";
					returnEmailId(Dept);
					
					break;
					case 2 : //System.out.println("Admin Option is selected");
					Dept = "Adm";					
					returnEmailId(Dept);
					break;
					case 3 : //System.out.println("HR Option is selected");
					Dept = "HR";
					returnEmailId(Dept);
					break;
					case 4 : //System.out.println("Legal Option is selected");
					Dept = "lg";
					returnEmailId(Dept);
					break;
					default:
					System.out.println("Invalid Option is selected");
					break;					
				}				
		}
		public static void displayMenu() {
			System.out.println("Please Enter the Department From the Following:");
			System.out.println("1. Technical");
			System.out.println("2. Admin");
			System.out.println("3. HR");
			System.out.println("4. Legal");
		}
		public static void returnEmailId(String dept) {
			String firstName = employee.getFirstName();
			String lastName = employee.getLastName();
			
			test = Credential.generateEmailAddress(firstName, lastName, dept);
			System.out.println("Dear " + firstName + " Your Credentials are as follows: " );
			System.out.println("Email Id is " + test);
			System.out.println("Password is " +Credential.Password());
		}
}