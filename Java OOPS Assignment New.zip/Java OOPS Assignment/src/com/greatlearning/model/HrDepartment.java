package com.greatlearning.model;

public class HrDepartment extends SuperDepartment {

	public static String departmentName() {
		return (" HR Department ");
		}
	
	public static String getTodaysWork() {
		return (" Fill today�s timesheet and mark your attendance " );
		}
	
	public static String getWorkDeadline() {
		return (" Complete by EOD ");
		}
	
	public static String doActivity() {
		return (" team Lunch ");
		}

}
