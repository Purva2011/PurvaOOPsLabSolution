package com.greatlearning.model;

public class SuperDepartment {

	public static String departmentName() {
		return (" Super Department ");
		}
	
	public static String getTodaysWork() {
		return (" No Work as of now ");
		}
	
	public static String getWorkDeadline() {
		return (" Nil ");
		}
	
	public static String isTodayAHoliday() {
		return (" Today is not a holiday ");
		}
 
}
