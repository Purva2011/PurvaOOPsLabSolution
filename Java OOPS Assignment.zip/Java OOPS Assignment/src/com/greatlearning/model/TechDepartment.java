package com.greatlearning.model;

public class TechDepartment extends SuperDepartment {

	public static String departmentName() {
		return (" Tech Department ");
		}
	
	public static String getTodaysWork() {
		return (" Complete coding of module 1 " );
		}
	
	public static String getWorkDeadline() {
		return (" Complete by EOD ");
		}
	
	public static String getTechStackInformation() {
		return (" core Java ");
		}
}
