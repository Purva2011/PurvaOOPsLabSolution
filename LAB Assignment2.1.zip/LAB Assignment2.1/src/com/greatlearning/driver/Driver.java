package com.greatlearning.driver;
import java.util.Scanner;

import com.greatlearning.services.TrnsectionTarget;

public class Driver {

public static void main(String [] args) {
	Scanner scanner = new Scanner(System.in);
	TrnsectionTarget Tran = new TrnsectionTarget();
	System.out.println("enter the totalNoOfTransactions of the transaction array");
	int totalNoOfTransactions = scanner.nextInt();
	int[] transcations = new int[totalNoOfTransactions];

	System.out.println("enter the value of transcations");
	for (int i = 0; i < totalNoOfTransactions; i++)
	transcations[i] = scanner.nextInt();

	System.out.println("enter the total no of targets that needs to be achieved");
	int targetCount = scanner.nextInt();
	System.out.println("Enter the value of targets");
	int target = 0;
	for(int i = 0; i< totalNoOfTransactions; i++)
	target = scanner.nextInt();
	Tran.processTransactions(transcations, target);

		}

}
